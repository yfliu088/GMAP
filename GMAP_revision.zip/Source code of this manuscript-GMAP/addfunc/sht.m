function [node,face]=sht(node_pc,n)
node=node_pc;
N=size(node,1);
[phim,thetam,r]=cart2sph((node(:,1))',(node(:,2))',(node(:,3))');
phi=phim;
theta=pi/2-thetam;
%
l=0:1:n;
m=(-1*n):1:n;
k2=1;
for i=1:length(l)
    nn=l(i);
    mm=(-1*nn):1:nn;
    for j=1:length(mm)
        ymark(k2,1)=l(i);
        ymark(k2,2)=mm(j);
        k2=k2+1;
    end
end
%
for i=1:(k2-1)
    yme=GetSphericalHarmonicFcn1(ymark(i,1), ymark(i,2), theta, phi);
    Y(:,i)=yme;
end
%
r=r';
a=linsolve(Y,r);
%
for i=1:(k2-1)
    yme=GetSphericalHarmonicFcn1(ymark(i,1), ymark(i,2), theta, phi);
    YYY(:,i)=yme;
end
aaa=a;
rsh=YYY*aaa;
rsh=real(rsh);
r=rsh';
%
R = abs(r);       
Rxy = R.*sin(theta);    
x = Rxy.*cos(phi);
y = Rxy.*sin(phi);
z = R.*cos(theta);
node=[x',y',z'];
[face]=facegen(node);
end

function Ylm = GetSphericalHarmonicFcn1(l, m, lTheta, lPhi)
if (isscalar(lTheta))
  lTheta = linspace(0, pi, lTheta);
end
if (isscalar(lPhi))
  lPhi = linspace(-pi, pi, lPhi);
end
nTheta = length(lTheta);
nPhi = length(lPhi);
% 
if (mod(m, 2)==1)
  neg1_m = -1;
else
  neg1_m = 1;
end
%
Nl = legendre(l, cos(lTheta), 'norm');
if (m >= 0)
  Nlm = Nl(m+1, :);
else
  Nlm = neg1_m * Nl(-m+1, :);
end
%
Ylm = neg1_m * sqrt(1/2/pi) * Nlm .*exp(1i*m*lPhi);
end
