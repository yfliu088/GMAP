function h=sphimgplot(imfg,node_fp,t_fp)
p=node_fp;
t=t_fp;
Hnode=[p,imfg'];
figure('color',[1,1,1])
h=plotsurf(Hnode,t);
axis equal off;
view(15,35);
set(h,'EdgeColor','none');
end


