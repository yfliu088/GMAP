function h=shapeplot(node,face)
t=face;
figure('color',[1,1,1])
h=plotsurf(node,t);
axis equal off;
set(h,'EdgeColor','none');
set(h,'FaceColor',[0.5,0.5,0.5]);
view(15,35);
camlight;
end


