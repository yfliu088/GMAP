function [mbbv,LWH]=mbb(node)
x=node(:,1);
y=node(:,2);
z=node(:,3);
N1=20;
ax=linspace(0,2*pi,N1);
by=linspace(0,2*pi,N1);
cz=linspace(0,2*pi,N1);
areamin=1e20;
for i=1:N1
    for j=1:N1
        for k=1:N1
            a=ax(i);
            b=by(j);
            th=cz(k);
            Rx=[1 0 0 0;0 cos(a) sin(a) 0;0 -sin(a) cos(a) 0;0 0 0 1];
            Ry=[cos(b) 0 -sin(b) 0;0 1 0 0;sin(b) 0 cos(b) 0;0 0 0 1];
            Rz=[cos(th) sin(th) 0 0;-sin(th) cos(th) 0 0;0 0 1 0;0 0 0 1];
            TT=Rx*Ry*Rz;
            pos=[x,y,z];
            N=length(x);
            posz=[pos ones(N,1)]*TT;
            post=posz(:,1:3);
            vt1=max(post);
            vt2=min(post);
            ckg=vt1-vt2;
            area=ckg(1)*ckg(2)*ckg(3);
            if area<areamin
                areamin=area;
                mina=a;
                ai=i;
                minb=b;
                bj=j;
                minc=th;
                ck=k;
                x1=vt1(1);
                x2=vt2(1);
                y1=vt1(2);
                y2=vt2(2);
                z1=vt1(3);
                z2=vt2(3);
                vtxmin=[x1 y1 z1;x1 y1 z2;x1 y2 z1;x1 y2 z2;x2 y1 z1;x2 y1 z2;...
                    x2 y2 z1;x2 y2 z2];
                ckgmin=ckg;
            end
        end
    end
end
N2=20;
ax=linspace(ai-2*pi/N1,ai+2*pi/N1,N2);
by=linspace(bj-2*pi/N1,bj+2*pi/N1,N2);
cz=linspace(ck-2*pi/N1,ck+2*pi/N1,N2);
for i=1:N2
    for j=1:N2
        for k=1:N2
            a=ax(i);
            b=by(j);
            th=cz(k);
            Rx=[1 0 0 0;0 cos(a) sin(a) 0;0 -sin(a) cos(a) 0;0 0 0 1];
            Ry=[cos(b) 0 -sin(b) 0;0 1 0 0;sin(b) 0 cos(b) 0;0 0 0 1];
            Rz=[cos(th) sin(th) 0 0;-sin(th) cos(th) 0 0;0 0 1 0;0 0 0 1];
            TT=Rx*Ry*Rz;
            pos=[x,y,z];
            N=length(x);
            posz=[pos ones(N,1)]*TT;
            post=posz(:,1:3);
            vt1=max(post);
            vt2=min(post);
            ckg=vt1-vt2;
            area=ckg(1)*ckg(2)*ckg(3);
            if area<areamin
                areamin=area;
                mina=a;
                ai=i;
                minb=b;
                bj=j;
                minc=th;
                ck=k;
                x1=vt1(1);
                x2=vt2(1);
                y1=vt1(2);
                y2=vt2(2);
                z1=vt1(3);
                z2=vt2(3);
                vtxmin=[x1 y1 z1;x1 y1 z2;x1 y2 z1;x1 y2 z2;x2 y1 z1;x2 y1 z2;...
                    x2 y2 z1;x2 y2 z2];
                ckgmin=ckg;
            end
        end
    end
end
a=-1*mina;
b=-1*minb;
th=-1*minc;
Rx=[1 0 0 0;0 cos(a) sin(a) 0;0 -sin(a) cos(a) 0;0 0 0 1];
Ry=[cos(b) 0 -sin(b) 0;0 1 0 0;sin(b) 0 cos(b) 0;0 0 0 1];
Rz=[cos(th) sin(th) 0 0;-sin(th) cos(th) 0 0;0 0 1 0;0 0 0 1];
TT=Rx*Ry*Rz;
vtxe=[vtxmin ones(8,1)]*TT;
mbbv=vtxe(:,1:3);
LWH=sort(ckgmin);
end

