function [En,tmc,stgau,stmc,stra]=spp1p2desc(node,face)
[Gaus]=Gausscurv(node,face);
[meanc]=meancurv(node,face);
[relarea]=relativearea(node,face);
En=sum(Gaus);
tmc=sum(meanc);
stgau=std(Gaus);
stmc=std(meanc);
stra=std(relarea);
end

