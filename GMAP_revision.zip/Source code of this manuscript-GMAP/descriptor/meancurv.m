function [meanc]=meancurv(node,face)
  op=node;
  t=face;
  % 
  [newnode,newface]=surfreorient(op,t);
  snorm=surfacenorm(newnode,newface);
  newcen=mean(newnode);
  [edges,idx,edgemap]=uniqedges(newface);
  [conn,connnum,count]=neighborelem(newface,N);
  fac=zeros(1,2);
  mec=zeros(1,size(edges,1));
  flag1=ones(1,size(edges,1));
  ecen=zeros(size(edges,1),3);
  for i=1:size(edges,1)
      fac=intersect(cell2mat(conn(edges(i,1))),cell2mat(conn(edges(i,2))));
      n1=snorm(fac(1),:);
      n2=snorm(fac(2),:);
      mec(i)=real(acos(dot(n1,n2)/(norm(n1)*norm(n2))));
      ecen(i,:)=(newnode(edges(i,1),:)+newnode(edges(i,2),:))./2;
      A=newface(fac(1),:);
      B=edges(i,:);
      C=newface(fac(2),:);
      pd1=setdiff(A, B);
      pd2=setdiff(C, B);
      pd=(newnode(pd1,:)+newnode(pd2,:))./2;
      ff=norm(pd-newcen)-norm(ecen(i,:)-newcen);
      flag1(i)=1*(ff<=0)+(-1)*(ff>0);
  end
  mece=mec.*flag1;
  %
  sy=reshape(edgemap,1,3*size(edgemap,1));
  meface=reshape(mece(sy),size(edgemap,1),3);
  mcfc=mean(meface,2);
  %
  mcvt=zeros(1,N);
  for j=1:N
      mcvt(j)=mean(mcfc(cell2mat(conn(j))));
  end
%
[conn2,connnum2,count2]=meshconn(newface,N);
mcvt2=mcvt;
mcvtd=mcvt;
for k=1:20
  for j=1:N
      zzz=[connnum2(j),connnum2(cell2mat(conn2(j)))];
      if sum(zzz~=6)
          mcvt2(j)=mean(mcvtd(cell2mat(conn2(j))));
      end
  end
  mcvtd=mcvt2;
end
meanc=mcvtd;
end

