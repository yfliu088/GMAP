function b = dilate3s(a,se)
widtho=max(size(a));
siz=max(size(se));
r=(siz-1)/2;
n=widtho+siz-1;
aa=zeros(n,n,n);
aa(r+1:n-r,r+1:n-r,r+1:n-r)=a;
a=aa;
width=max(size(a));
b=a;
% c=a(r+1:width-r,r+1:width-r,r+1:width-r);
c=zeros(widtho,widtho,widtho);
for i=1:siz
    for j=1:siz
        for k=1:siz
            xind=i:width-siz+i;
            yind=j:width-siz+j;
            zind=k:width-siz+k;
            c=c+(a(xind,yind,zind)&se(i,j,k));
%             b(xind,yind,zind)=c*se(i,j,k);
        end
    end
end
b=c>0;
% b=c(r+1:width-r,r+1:width-r,r+1:width-r);
end

