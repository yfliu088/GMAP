%By Y.F.Liu-2022.7.22
%��������������������
function BD=openc3d(img,a1,a2)
Nb=a2;
BB=img;
cc=cell(1,Nb);
parfor i=a1:a2
o_r=i;
aa=2*o_r+1;
o_x=o_r+1;
o_y=o_r+1;
o_z=o_r+1;
[x,y,z]=meshgrid(1:aa,1:aa,1:aa);
se=1.*((x-o_x).^2+(y-o_y).^2+(z-o_z).^2<=o_r.^2);
BC=open3(BB,se);
cc(1,i)={BC};
% subplot(121),imshow(BB(:,:,32));
% subplot(122),imshow(BC(:,:,32));
end
BD=0.*BB;
for j=a1:a2
    BD=BD+cell2mat(cc(1,j));
end
BD=BD+BB.*(a1-1);
end





        







