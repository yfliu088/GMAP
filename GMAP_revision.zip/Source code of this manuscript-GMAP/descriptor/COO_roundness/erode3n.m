function b = erode3n(a,se)
%erode3 General sliding-neighborhood operations.
nhood=size(se);
b = false(size(a)+nhood-1);
a=logical(a);
a=~a;

siza = size(a);



% Find out what output type to make.
rows = 0:(nhood(1)-1);
cols = 0:(nhood(2)-1);
dpths= 0:(nhood(3)-1);


idx=find(a);
[xi, yi, zi]=ind2sub(siza,idx);

for i=1:length(xi)
    b(xi(i)+rows,yi(i)+cols,zi(i)+dpths)=b(xi(i)+rows,yi(i)+cols,zi(i)+dpths) | se;
end

% for i=1:siza(1),
%     for j=1:siza(2),
%         for k=1:siza(3),
%             
%             if a(i,j,k)
%                b(i+rows,j+cols,k+dpths)=b(i+rows,j+cols,k+dpths) | se;
%             end
%         end
%     end
% end
nhood=(nhood+1)/2;
b=b(nhood(1):end-nhood(1)+1,nhood(2):end-nhood(2)+1,nhood(3):end-nhood(3)+1);
b=~b;

end
