%b=open3s(a,se)
function b=open3s(a,se)
b=dilate3s(erode3s(a,se),se);
end