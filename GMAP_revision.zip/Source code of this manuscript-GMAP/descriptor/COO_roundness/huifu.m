function BB1 = huifu(BB,BD1)
%BDX->BD
lt=size(BB,1);
ll=size(BD1,1);
nt=lt/ll;
xind=1:nt:lt-nt+1;
yind=1:nt:lt-nt+1;
zind=1:nt:lt-nt+1;
% BD1n=BD1;
BB1=BB.*1;
for i=1:nt
    for j=1:nt
        for k=1:nt
            BB1(xind+i-1,yind+j-1,zind+k-1)=BB(xind+i-1,yind+j-1,zind+k-1).*BD1;
        end
    end
end
end
