%b=open3(a,se)



function b=open3(a,se)
b=dilate3(erode3(a,se),se);
end