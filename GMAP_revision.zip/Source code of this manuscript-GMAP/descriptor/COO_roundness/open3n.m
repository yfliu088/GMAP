%b=open3(a,se)



function b=open3n(a,se)
b=dilate3n(erode3n(a,se),se);
end