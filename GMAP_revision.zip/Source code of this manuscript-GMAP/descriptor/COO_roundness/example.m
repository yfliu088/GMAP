%By Y.F.Liu-2022.7.22
%continuous open operation

clc
clear all
% %Open parallel computing
% parpool local
% %matlabpool OPEN
tic
tsn1=63;
tsn2=127;
tsn3=255;
tsn4=511;

%% Convert .stl to voxels
[f,n,v]=stlread('LS048.stl');
xo=mean(f);
yo=mean(n);
zo=mean(v);
xx=xo'-mean(xo);
yy=yo'-mean(yo);
zz=zo'-mean(zo);
[theta0,lambda0,r0]=cart2sph(xx,yy,zz);
theta0=theta0+pi;
lambda0=lambda0+pi/2;
%near refine
N=20000;
fai=(sqrt(5)-1)/2;
for i=1:N
    zf(i)=(2*i-1)/N-1;
    xf(i)=sqrt(1-zf(i)^2)*cos(2*pi*i*fai);
    yf(i)=sqrt(1-zf(i)^2)*sin(2*pi*i*fai);
end
[phim,thetam,rf]=cart2sph(xf,yf,zf);
phi=phim+pi;
theta=pi/2-thetam;
r = griddata(theta0,lambda0,r0,phi,theta,'nearest');
R = abs(r);       % according to color
Rxy = R.*sin(theta);    % convert to Cartesian coordinates
x = Rxy.*cos(phi);
y = Rxy.*sin(phi);
z = R.*cos(theta);
[phimo,thetamo,ro]=cart2sph(-x,-y,z);
node=[phimo',thetamo',ro'];
mro=mean(ro);
nodej=[phimo',thetamo',ro'-mro];
sphcd=[phim',thetam'];
[xt,yt,zt]=sph2cart(phim,thetam,rf+0.001.*rand(1,N));
p=[xt',yt',zt'];
[t]=MyCrust(p);
originode=[-x',-y',z',ro'];
%
RG=ro;
[xz,yz,zz]=sph2cart((sphcd(:,1))',(sphcd(:,2))',RG);
Rnode=[xz',yz',zz',RG'];
pp=Rnode(:,1:3);
%
[newnode,newface]=surfreorient(pp,t);
%volume
RgV=surfvolume(newnode,newface);
VO=4/3*pi;
sv=VO/RgV;
sl=sv^(1/3);
newnode=sl.*newnode;
% %img1
% ljx=max(max(max(abs(newnode))))*1.1;
% xi=linspace(-ljx,ljx,tsn1+1);
% yi=linspace(-ljx,ljx,tsn1+1);
% zi=linspace(-ljx,ljx,tsn1+1);
% img1=surf2vol(newnode,newface,xi,yi,zi,'fill',1);
% %img2
% ljx=max(max(max(abs(newnode))))*1.1;
% xi=linspace(-ljx,ljx,tsn2+1);
% yi=linspace(-ljx,ljx,tsn2+1);
% zi=linspace(-ljx,ljx,tsn2+1);
% img2=surf2vol(newnode,newface,xi,yi,zi,'fill',1);
% %img3
% ljx=max(max(max(abs(newnode))))*1.1;
% xi=linspace(-ljx,ljx,tsn3+1);
% yi=linspace(-ljx,ljx,tsn3+1);
% zi=linspace(-ljx,ljx,tsn3+1);
% img3=surf2vol(newnode,newface,xi,yi,zi,'fill',1);
% %img4
ljx=max(max(max(abs(newnode))))*1.1;
xi=linspace(-ljx,ljx,tsn4+1);
yi=linspace(-ljx,ljx,tsn4+1);
zi=linspace(-ljx,ljx,tsn4+1);
img4=surf2vol(newnode,newface,xi,yi,zi,'fill',1);
img3 = hebing(img4,2);
img2=hebing(img3,2);
img1=hebing(img2,2);

% imgo2=img2;
% imgo3=img3;
% imgo4=img4;
% for i=1:24
%     imgo4=imgo4-bwperim(imgo4);
%     imgo3=imgo3-bwperim(imgo3);
%     imgo2=imgo2-bwperim(imgo2);
% end
% img4n=img4-imgo4;
% img3n=img3-imgo3;
% img2n=img2-imgo2;


%
BD1=openc3d(img1,8,30);
disp('64 is done');
toc
BD2=openc3d(img2,8,16);
disp('128 is done');
toc
BD3=openc3d(img3,8,16);
disp('256 is done');
toc
% BD4=openc3d(img4,8,16);
% disp('512 is done');
% toc

%BDX->BD
BB=img3;
% BB=img4;
BB1=huifu(BB,BD1);
BB2=huifu(BB,BD2)./2;
% BB3=huifu(BB,BD3)./4;
BB3=BD3./4;
% BB4=BD4./8;
BBZ=BB1;
BBZ(BB2<8 & BB2)=BB2(BB2<8 & BB2);
BBZ(BB3<4 & BB3)=BB3(BB3<4 & BB3);
% BBZ(BB4<2 & BB4)=BB4(BB4<2 & BB4);

%% plot
tsn=tsn3;
img=img3;
BD=BBZ;
imgo4=img;
for i=1:2
    imgo4=imgo4-bwperim(imgo4);
end
imgl=bwperim(imgo4);
siza = size(imgl);
idx=find(imgl);
[xi, yi, zi]=ind2sub(siza,idx);
rrz=zeros(1,length(xi));
for i=1:length(xi)
    rrz(i)=BBZ(xi(i),yi(i),zi(i));
end
figure('color',[1,1,1]);
scatter3(xi,yi,zi,3,rrz','fill');
axis equal off;

% 
xo=mean(xi);
yo=mean(yi);
zo=mean(zi);
xx=xi'-mean(xo);
yy=yi'-mean(yo);
zz=zi'-mean(zo);
[theta0,lambda0,r0]=cart2sph(xx,yy,zz);
theta0=theta0+pi;
lambda0=lambda0+pi/2;
% 
N=20000;
fai=(sqrt(5)-1)/2;
for i=1:N
    zf(i)=(2*i-1)/N-1;
    xf(i)=sqrt(1-zf(i)^2)*cos(2*pi*i*fai);
    yf(i)=sqrt(1-zf(i)^2)*sin(2*pi*i*fai);
end
[phim,thetam,rf]=cart2sph(xf,yf,-zf);
phi=phim+pi;
theta=pi/2-thetam;
rn = griddata(theta0,lambda0,rrz',phi,theta,'nearest');

%
[conn,connnum,count]=meshconn(t,N);
 for j=1:N
      rnn(j)=mean(rn(cell2mat(conn(j))));
 end

% plot
Rnode=[newnode,rnn'];
figure('color',[1,1,1])
hr=plotsurf(Rnode,t);
axis equal off;
colormap parula;
set(hr,'EdgeColor','none');
            
