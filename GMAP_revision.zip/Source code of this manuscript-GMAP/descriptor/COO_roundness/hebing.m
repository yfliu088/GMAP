function img2 = hebing(img1,n)
%BDX->BD
tt=n^3;
nt=n;
lt=size(img1,1);
ll=lt/nt;
img2=zeros(ll,ll,ll);
xind=1:nt:lt-nt+1;
yind=1:nt:lt-nt+1;
zind=1:nt:lt-nt+1;
BB=img2;
for i=1:nt
    for j=1:nt
        for k=1:nt
            BB=BB+img1(xind+i-1,yind+j-1,zind+k-1);
        end
    end
end
img2=BB>0;
end
