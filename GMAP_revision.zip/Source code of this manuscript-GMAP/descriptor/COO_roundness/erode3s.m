function b = erode3s(a,se)
c=~a;
d=dilate3s(c,se);
b=~d;
end