function [relarea]=relativearea(node,face)
op=node;
t=face;
N=size(node,1);
[phim,thetam,rff]=cart2sph((node(:,1))',(node(:,2))',(node(:,3))');
rf=mean(rff).*ones(1,N);
[xo,yo,zo]=sph2cart(phim,thetam,rf);
Ro=[xo',yo',zo'];
trangr=zeros(1,size(t,1));
trangs=zeros(1,size(t,1));
abl=zeros(1,size(t,1));
for i=1:size(t,1)
    ar=op(t(i,1),:);
    br=op(t(i,2),:);
    cr=op(t(i,3),:);
    as=Ro(t(i,1),:);
    bs=Ro(t(i,2),:);
    cs=Ro(t(i,3),:);
    trangr(i)=0.5*norm(cross((br-ar),(cr-ar)));
    trangs(i)=0.5*norm(cross((bs-as),(cs-as)));
    abl(i)=trangr(i)/trangs(i);
end
[conn,connnum,count]=neighborelem(t,N);
abv=zeros(1,N);
for i=1:N
    ttran=cell2mat(conn(i));
    abv(i)=mean(abl(ttran));
end
relarea=abv;
end

