function struci=strucindex(node,face)
op=node;
t=face;
N=size(node,1);
[phim,thetam,rff]=cart2sph((node(:,1))',(node(:,2))',(node(:,3))');
rf=mean(rff).*ones(1,N);
[xo,yo,zo]=sph2cart(phim,thetam,rf);
sphcd=[phim',thetam',rff'];
Ro=[xo',yo',zo'];
[mc1]=meancurv(op,t);
[mc2]=meancurv(Ro,t);
NC=1000;
zj1=mc1;
zj2=mc2;
zjj=zj1./zj2;
[cg,cc]=sort(zjj,'descend');
% ccor=find(zj1>2*zj2);
ccor=cc(1:NC);
pnode=sphcd(ccor,:);
rz1=dentropy(pnode);
NC2=length(ccor);
fai=(sqrt(5)-1)/2;
for i=1:NC2
    z_nc(i)=(2*i-1)/NC2-1;
    x_nc(i)=sqrt(1-z_nc(i)^2)*cos(2*pi*i*fai);
    y_nc(i)=sqrt(1-z_nc(i)^2)*sin(2*pi*i*fai);
end
[phimnc,thetamnc,rfnc]=cart2sph(x_nc,y_nc,z_nc);
bpnode=[phimnc',thetamnc'];
rz2=dentropy(bpnode);
struci=rz1/rz2;
end

function enp=dentropy(pnode)
phi0=pnode(:,1)';
theta0=pnode(:,2)';
N=20;
fai=(sqrt(5)-1)/2;
for i=1:N
    zf(i)=(2*i-1)/N-1;
    xf(i)=sqrt(1-zf(i)^2)*cos(2*pi*i*fai);
    yf(i)=sqrt(1-zf(i)^2)*sin(2*pi*i*fai);
end
[phi,theta,rf]=cart2sph(xf,yf,zf);
phi0c=repmat(phi0,length(phi),1);
phi0c=phi0c';
theta0c=repmat(theta0,length(phi),1);
theta0c=theta0c';
phic=repmat(phi,length(phi0),1);
thetac=repmat(theta,length(phi0),1);
d=real(acos(sin(theta0c).*sin(thetac)+cos(theta0c).*cos(thetac).*cos(phi0c-phic)));
[Ag,Ac]=sort(d,2);
dd=Ac(:,1);
dd=dd';
aa=tabulate(dd);
p=(aa(:,3))'./100;
p(find(p==0))=[];
enp=-1.*sum(p.*(log(p)./log(N)));
end


