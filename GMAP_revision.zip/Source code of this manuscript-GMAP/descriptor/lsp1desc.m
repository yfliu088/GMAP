function [elong,flatr,flati,shapef,tsph]=lsp1desc(node,face)
[Ll,Li,Ls,SF,VL]=basicpara(node,face);
elong=Ls/Li;
flatr=Li/Ll;
flati=(Ll+Li)/(2*Ls);
shapef=Ls/sqrt(Li*Ll);
tsph=((36*pi*VL^2)^(1/3))/SF;
end

