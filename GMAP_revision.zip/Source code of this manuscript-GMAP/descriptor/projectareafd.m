function pcfd=projectareafd(node,face)
scm=1:8;
numc=2.^(scm);
N=size(node,1);
Nz=round(N./numc);
img=node;
tt=face;
SF=zeros(1,length(Nz));
for i=1:length(Nz)
    Ng=Nz(i);
    [node_fp,t_fp]=fibonacci(Ng);
    [node_ng,face_ng]=pc2fib(img,node_fp,t_fp);
    REgn=node_ng;
    t=face_ng;
    trangr=zeros(1,size(t,1));
    for j=1:size(t,1)
      ar=REgn(t(j,1),:);
      br=REgn(t(j,2),:);
      cr=REgn(t(j,3),:);
      trangr(j)=0.5*norm(cross((br-ar),(cr-ar)));
    end
SF(i)=sum(trangr);
end
pcfd=SF;
end


