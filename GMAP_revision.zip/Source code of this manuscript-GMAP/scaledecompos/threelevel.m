function [kl,kg,imfg,REl,REg] = threelevel(res,Ne,Nel,Neg)
RE=res;
i=size(res,1)-1;
en=Ne;
for kr=1:i
    if en(kr)<Nel
        imfg=RE(kr+1,:)-RE(1,:);
        REl=RE(kr,:);
        kl=kr;
        break;
    end
end
for kr=1:i
    if en(kr)<Neg
        REg=RE(kr,:);
        kg=kr;
        break;
    end
end
end