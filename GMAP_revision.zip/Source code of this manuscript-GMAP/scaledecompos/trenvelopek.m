function enve=trenvelopek(node,sphcd)
phi0=node(:,1)';
theta0=node(:,2)';
rf0 = node(:,3)';
phi=sphcd(:,1)';
theta=sphcd(:,2)';
Nt=length(phi0);
N=length(phi);
xs=[phi0' theta0'];
xe=[phi' theta'];
d_ij=real(ddis(xs,xs));
d_io=ddis(xs,xe);
% variational function
% [conn,connnum,count]=meshconn(t,Nt);
%  for j=1:Nt
%       a_d(j)=mean(d_ij(j,cell2mat(conn(j))));
%  end
% a_e=1.*mean(a_d);
% a_e=0.5;
a_e=3.814./sqrt(Nt);
c_e=1;
% exponential model
% r_ij=c_e.*(1-exp(-3.*d_ij./a_e));
% r_io=c_e.*(1-exp(-3.*d_io./a_e));
% spherical model
% r_ij=c_e.*(1.5.*(d_ij)./a_e-0.5.*((d_ij)./a_e).^3).*(d_ij<=a_e)+c_e.*(d_ij>a_e);
% r_io=c_e.*(1.5.*(d_io)./a_e-0.5.*((d_io)./a_e).^3).*(d_io<=a_e)+c_e.*(d_io>a_e);
% Gaussian model
r_ij=c_e.*(1-exp(-(3.*d_ij./a_e).^2));
r_io=c_e.*(1-exp(-(3.*d_io./a_e).^2));
% 
A=zeros(Nt+1,Nt+1);
A(1:Nt,1:Nt)=r_ij;
A(Nt+1,:)=1;
A(:,Nt+1)=1;
A(Nt+1,Nt+1)=0;
B=ones(Nt+1,N);
B(1:Nt,:)=r_io;
L=r_io;
parfor i=1:N
    ll=A\B(:,i);
    L(:,i)=ll(1:Nt)';
end
ye=L'*rf0';
enve=ye';

end