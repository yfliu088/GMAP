function d=ddis(xs,xe)
phi0=xs(:,1)';
theta0=xs(:,2)';
phi=xe(:,1)';
theta=xe(:,2)';
phi0c=repmat(phi0,length(phi),1);
phi0c=phi0c';
theta0c=repmat(theta0,length(phi),1);
theta0c=theta0c';
phic=repmat(phi,length(phi0),1);
thetac=repmat(theta,length(phi0),1);
d=acos(sin(theta0c).*sin(thetac)+cos(theta0c).*cos(thetac).*cos(phi0c-phic));
end