function [imf,res,Ne]=semd(node_ps,node_fp,t_fp,thres)
phim=(node_fp(:,1))';
thetam=(node_fp(:,2))';
ro=(node_ps(:,4))';
mro=mean(ro);
nodej=[phim',thetam',ro'-mro];
t=t_fp;
N=size(node_ps,1);
H=zeros(20,N);
imf=zeros(20,N);
RE=zeros(21,N);
eminn=zeros(1,20);
emaxn=zeros(1,20);
en=zeros(1,20);
rrr=nodej;
RE(1,:)=ro;
for i=1:20
  for k=1:20
     rko=rrr(:,3)';
     ming=tremin(rrr,t);
     maxg=tremax(rrr,t);
     minenr=trenvelope(ming,sphcd);
     maxenr=trenvelope(maxg,sphcd);
     meanr=(minenr+maxenr)./2;
     H(k,:)=rko-meanr;
     rrr=[phim',thetam',(H(k,:))'];
     if k>1
         if sum((H(k,:)-H(k-1,:)).^2)/sum(H(k-1,:).^2)<thres
             break;
         end
     end
  end
  imf(i,:)=H(k,:);
  RE(i+1,:)=RE(i,:)-imf(i,:);
  rrr=[phim',thetam',(RE(i+1,:)-mro)'];
  maxnum=size(maxg);
  minnum=size(ming);
  eminn(i)=minnum(1);
  emaxn(i)=maxnum(1);
  enum=maxnum(1)+minnum(1);
  en(i)=enum;
  if i>1
    if enum>=en(i-1)
        break;
    end
  end
end
ktn=i;
imf(ktn+1:20,:)=[];
RE(ktn+2:20,:)=[];
res=RE;
Ne=en;
end

