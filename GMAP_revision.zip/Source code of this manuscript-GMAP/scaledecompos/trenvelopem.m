function enve=trenvelopem(node,sphcd)
phi0=node(:,1)'-0.000001;
theta0=node(:,2)'-0.000001;
rf0 = node(:,3)';
phi=sphcd(:,1)';
theta=sphcd(:,2)';
xs=[phi0' theta0'];
ys=rf0';
xe=[phi' theta'];
d_io=ddis(xs,xe);
% radius of influence around node
a_e=5*3.814/sqrt(length(phi0));
dd=((a_e-d_io).*(a_e>d_io)./(a_e.*d_io)).^2;
ww=dd./sum(dd);
ys=rf0';
ye=ww'*ys;
enve=ye';
end