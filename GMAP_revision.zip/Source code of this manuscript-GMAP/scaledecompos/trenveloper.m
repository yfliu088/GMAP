function enve=trenveloper(node,sphcd)
phi0=node(:,1)'-0.000001;
theta0=node(:,2)'-0.000001;
rf0 = node(:,3)';
phi=sphcd(:,1)';
theta=sphcd(:,2)';
xs=[phi0' theta0'];
ys=rf0';
xe=[phi' theta'];
d_ij=real(ddis(xs,xs));
d_io=ddis(xs,xe);
%Radial basis function
[conn,connnum,count]=meshconn(t,Nt);
 for j=1:Nt
      a_d(j)=mean(d_ij(j,cell2mat(conn(j))));
 end
a_e=10.*mean(a_d); %
c_e=1;
% Gaussian function
% r_ij=c_e.*(exp(-(d_ij./a_e).^2));
% r_io=c_e.*(exp(-(d_io./a_e).^2));
% thin plate spline function
% r_ij=c_e.*(d_ij.^2.*log(d_ij+1));
% r_io=c_e.*(d_io.^2.*log(d_io+1));
% power function
r_ij=d_ij.^(-3);
r_io=d_io.^(-3);
%...
ww=r_ij'\rf0';
rg=ww'*r_io;
enve=rg';
end