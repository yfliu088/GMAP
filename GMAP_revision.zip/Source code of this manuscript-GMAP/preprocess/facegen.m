function [t]=facegen(p)
starttime=clock;

tic
p=AddShield(p);
fprintf('Addedded Shield: %4.4f s\n',toc)

tic
tetr=delaunayn(p);%
tetr=int32(tetr);%
fprintf('Delaunay Triangulation Time: %4.4f s\n',toc)
%
tic
[t2tetr,tetr2t]=Connectivity(tetr);
fprintf('Connectivity Time: %4.4f s\n',toc)
tic
[cc,r]=CC();%
fprintf('Circumcenters Time: %4.4f s\n',toc)
clear n

tic
t=Walking();%
fprintf('Walking Time: %4.4f s\n',toc)

time=etime(clock,starttime);
fprintf('Total Time: %4.4f s\n',time)

%
    function [cc,r]=CC()
         %       
        p1=(p(tetr(:,1),:));
        p2=(p(tetr(:,2),:));
        p3=(p(tetr(:,3),:));
        p4=(p(tetr(:,4),:));
        %
        v21=p(tetr(:,1),:)-p(tetr(:,2),:);
        v31=p(tetr(:,3),:)-p(tetr(:,1),:);
        v41=p(tetr(:,4),:)-p(tetr(:,1),:);
        %
        cc=zeros(size(tetr,1),3);
         %
        d1=sum(v41.*(p1+p4)*.5,2);
        d2=sum(v21.*(p1+p2)*.5,2);
        d3=sum(v31.*(p1+p3)*.5,2);

        det23=(v21(:,2).*v31(:,3))-(v21(:,3).*v31(:,2));
        det13=(v21(:,3).*v31(:,1))-(v21(:,1).*v31(:,3));
        det12=(v21(:,1).*v31(:,2))-(v21(:,2).*v31(:,1));

        Det=v41(:,1).*det23+v41(:,2).*det13+v41(:,3).*det12;

        detx=d1.*det23+...
            v41(:,2).*(-(d2.*v31(:,3))+(v21(:,3).*d3))+...
            v41(:,3).*((d2.*v31(:,2))-(v21(:,2).*d3));

        dety=v41(:,1).*((d2.*v31(:,3))-(v21(:,3).*d3))+...
            d1.*det13+...
            v41(:,3).*((d3.*v21(:,1))-(v31(:,1).*d2));

        detz=v41(:,1).*((v21(:,2).*d3)-(d2.*v31(:,2)))...
            +v41(:,2).*(d2.*v31(:,1)-v21(:,1).*d3)...
            +d1.*(det12);
        %
        cc(:,1)=detx./Det;
        cc(:,2)=dety./Det;
        cc(:,3)=detz./Det;
         %
        r=((sum((p2-cc).^2,2))).^.5;%
    end
%

    function [t2tetr,tetr2t]=Connectivity(tetr)

        numt = size(tetr,1);
        vect = 1:numt;
        t = [tetr(:,[1,2,3]); tetr(:,[2,3,4]); tetr(:,[1,3,4]);tetr(:,[1,2,4])];%
        [t,j,j] = unique(sort(t,2),'rows');%
        t2tetr = [j(vect), j(vect+numt), j(vect+2*numt),j(vect+3*numt)];%
        %       
        nume = size(t,1);
        tetr2t  = zeros(nume,2,'int32');
        count= ones(nume,1,'int8');
        for k = 1:numt

            for j=1:4
                ce = t2tetr(k,j);
                tetr2t(ce,count(ce)) = k;
                count(ce)=count(ce)+1;
            end
        end
    end      % 
%
    function t=Walking()
        np=size(p,1)-540;%
        numtetr=size(tetr,1);
        nt=size(tetr2t,1);
        deleted=true(numtetr,1);%
        checked=false(numtetr,1);%
        onfront=false(nt,1);%
        countchecked=0;
        %
        for i=1:numtetr
            for j=1:4
                if tetr(i,j)>np;
                    deleted(i)=true;
                    checked(i)=true;
                    onfront(t2tetr(i,:))=true;
                    countchecked=countchecked+1;
                    break
                end
            end
        end
        %
        toll=zeros(nt,1)+.95; 
        level=0;
        
        alpha=zeros(nt,1);%
        %
        for i=1:nt
            if tetr2t(i,2)>0 %
                    distcc=sum((cc(tetr2t(i,1),:)-cc(tetr2t(i,2),:)).^2,2);%
                    %
                    alpha(i)=(-distcc+r(tetr2t(i,1))^2+r(tetr2t(i,2))^2)/(2*r(tetr2t(i,1))*r(tetr2t(i,2)));
            end
        end
        clear cc        
%         
        while countchecked<numtetr && level<50
             level=level+1;%           
            for id=1:nt%
                if onfront(id)
                    tetr1=tetr2t(id,1);tetr2=tetr2t(id,2);%
                    if  tetr2==0 %
                        onfront(id)=false;
                        continue
                       
                    elseif (checked(tetr1) && checked(tetr2)) %
                         onfront(id)=false;
                        continue
                       
                    end
                    if alpha(id)>=toll(id) %
                        if checked(tetr1)%
                            deleted(tetr2)=deleted(tetr1) ;%
                            checked(tetr2)=true;%
                            countchecked=countchecked+1;
                            onfront(t2tetr(tetr2,:))=true;%
                        else
                            deleted(tetr1)=deleted(tetr2) ;%
                            checked(tetr1)=true;%
                            countchecked=countchecked+1;
                            onfront(t2tetr(tetr1,:))=true;%
                        end
                         onfront(id)=false;%                 
                    elseif alpha(id)<-toll(id)
                        if checked(tetr1)
                            deleted(tetr2)=~(deleted(tetr1)) ;
                            checked(tetr2)=true;
                            countchecked=countchecked+1;
                            onfront(t2tetr(tetr2,:))=true;
                        else
                            deleted(tetr1)=~(deleted(tetr2)) ;
                            checked(tetr1)=true;
                            countchecked=countchecked+1;
                            onfront(t2tetr(tetr1,:))=true;
                        end
                         onfront(id)=false;                        
                    else
                        toll(id)=toll(id)-.05;
                    end
                end
            end
            
            if level==31 %
                 warning('Brute continuation necessary')
                onfront(t2tetr(~(checked),:))=true;%
            end
        end      
        %
        tetr(deleted,:)=[];     
        %
        t=BoundTriangles(tetr);      
        %
        numchecked=countchecked/numtetr;
        if level==50
            warning([num2str(level),' th level was reached\n'])
        else
         fprintf('%4.4f th level was reached\n',level)
        end
        fprintf('%4.4f %% of Tetraedrom were checked\n',numchecked*100)
    end
end

%
function pnew=AddShield(p)
%
maxx=max(p(:,1));
maxy=max(p(:,2));
maxz=max(p(:,3));
minx=min(p(:,1));
miny=min(p(:,2));
minz=min(p(:,3));
%
step=max(abs([maxx,minx,maxy,miny,maxz,minz]));
maxx=maxx+step;
maxy=maxy+step;
maxz=maxz+step;
minx=minx-step;
miny=miny-step;
minz=minz-step;
step=step/100;
N=10;
%
vx=linspace(minx,maxx,N);
vy=linspace(miny,maxy,N);
vz=linspace(minz,maxz,N);
[x,y]=meshgrid(vx,vy);
facez1=[x(:),y(:),ones(N*N,1)*maxz];
facez2=[x(:),y(:),ones(N*N,1)*minz];
[x,y]=meshgrid(vy,vz-step);
facex1=[ones(N*N,1)*maxx,x(:),y(:)];
facex2=[ones(N*N,1)*minx,x(:),y(:)];
[x,y]=meshgrid(vx-step,vz);
facey1=[x(:),ones(N*N,1)*maxy,y(:)];
facey2=[x(:),ones(N*N,1)*miny,y(:)];
%
pnew=[p;
 facex1;
 facex2;
 facey1;
 facey2;
 facez1;
 facez2];
end

%
function t=BoundTriangles(tetr)
numt = size(tetr,1);
vect = 1:numt;
t = [tetr(:,[1,2,3]); tetr(:,[2,3,4]); tetr(:,[1,3,4]);tetr(:,[1,2,4])];
[t,j,j] = unique(sort(t,2),'rows');
t2tetr = [j(vect), j(vect+numt), j(vect+2*numt),j(vect+3*numt)];
% 
nume = size(t,1);
tetr2t  = zeros(nume,2,'int32');
count= ones(nume,1,'int32');
for k = 1:numt
    for j=1:4
        ce = t2tetr(k,j);
        tetr2t(ce,count(ce)) = k;
        count(ce)=count(ce)+1;
    end
end
tbound=false(numt,1);
tbound=tetr2t(:,2)==0;
t=t(tbound,:);
end


