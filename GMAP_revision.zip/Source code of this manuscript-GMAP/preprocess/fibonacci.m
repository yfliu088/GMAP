function [node_fp,t_fp]=fibonacci(N)
fai=(sqrt(5)-1)/2;
for i=1:N
    zf(i)=(2*i-1)/N-1;
    xf(i)=sqrt(1-zf(i)^2)*cos(2*pi*i*fai);
    yf(i)=sqrt(1-zf(i)^2)*sin(2*pi*i*fai);
end
[phim,thetam,rf]=cart2sph(xf,yf,zf);
node_fp=[phim',thetam',rf'];
[xt,yt,zt]=sph2cart(phim,thetam,rf+0.001.*rand(1,N));
p=[xt',yt',zt'];
[t]=facegen(p);
t_fp=t;
end

