function [node,face]=pc2fib(img,node_fp,t_fp)
xo=(img(:,1));
yo=(img(:,2));
zo=(img(:,3));
xx=xo'-mean(xo);
yy=yo'-mean(yo);
zz=zo'-mean(zo);
[theta0,lambda0,r0]=cart2sph(xx,yy,zz);
theta0=theta0+pi;
lambda0=lambda0+pi/2;
%
phim=node_fp(:,1);
thetam=node_fp(:,2);
%
phi=phim+pi;
theta=pi/2-thetam;
r = griddata(theta0,lambda0,r0,phi,theta,'nearest');
R = abs(r);       
Rxy = R.*sin(theta);    
x = Rxy.*cos(phi);
y = Rxy.*sin(phi);
z = R.*cos(theta);
node=[-x',-y',z'];
face=t_fp;
end

