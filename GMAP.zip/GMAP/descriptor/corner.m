function [nodec]=corner(node,face)
op=node;
t=face;
N=size(node,1);
[phim,thetam,rff]=cart2sph((node(:,1))',(node(:,2))',(node(:,3))');
rf=mean(rff).*ones(1,N);
[xo,yo,zo]=sph2cart(phim,thetam,rf);
Ro=[xo',yo',zo'];
[mc1]=meancurv(op,t);
[mc2]=meancurv(Ro,t);
zj1=mc1;
zj2=mc2;
ccor=find(zj1>2*zj2);
nodec=node(ccor,:);
end

