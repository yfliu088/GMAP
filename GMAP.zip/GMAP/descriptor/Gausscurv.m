function [Gaus]=Gausscurv(node,face)
op=node;
t=face;
trang=zeros(size(t));
for i=1:size(t,1)
    aa=op(t(i,1),:);
    bb=op(t(i,2),:);
    cc=op(t(i,3),:);
    Aa=norm(bb-cc);
    Bb=norm(aa-cc);
    Cc=norm(aa-bb);
    trang(i,1)=acos((Bb^2 +Cc^2-Aa^2)/(2*Bb*Cc));
    trang(i,2)=acos((Aa^2 +Cc^2-Bb^2)/(2*Aa*Cc));
    trang(i,3)=acos((Bb^2 +Aa^2-Cc^2)/(2*Bb*Aa));
end
[conn,connnum,count]=neighborelem(t,N);
gau=zeros(1,N);
for i=1:N
    ttran=cell2mat(conn(i));
    k=connnum(i);
    fa=zeros(1,k);
    for j=1:k
        fa(j)=sum((t(ttran(j),:)==i).*trang(ttran(j),:));
    end
    gau(i)=2*pi-sum(fa);
end
Gaus=gau;
end

