function [Ll,Li,Ls,SF,VL]=basicpara(node,face)
[mbbv,LIS]=mbb(node);
Ll=LIS(3);
Li=LIS(2);
Ls=LIS(1);
%
REgn=node;
t=face;
VL=surfvolume(REgn,t);
%
trangr=zeros(1,size(t,1));
for i=1:size(t,1)
    ar=REgn(t(i,1),:);
    br=REgn(t(i,2),:);
    cr=REgn(t(i,3),:);
    trangr(i)=0.5*norm(cross((br-ar),(cr-ar)));
end
SF=sum(trangr);
end

