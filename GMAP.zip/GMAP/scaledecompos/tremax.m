function nt=tremax(node,ele)
r=node(:,3);
nn=length(r);
[conn,connnum,count]=meshconn(ele,nn);
k=1;
for i=1:nn
    if sum(r(i)<r(cell2mat(conn(i))))==0
        nt(k,:)=node(i,:);
        k=k+1;
    end
end

