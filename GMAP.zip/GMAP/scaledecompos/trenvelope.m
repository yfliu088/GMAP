function enve=trenvelope(node,sphcd)
phi0=node(:,1)'-0.000001;
theta0=node(:,2)'-0.000001;
rf0 = node(:,3)';
phi=sphcd(:,1)';
theta=sphcd(:,2)';
xs=[phi0' theta0'];
ys=rf0';
xe=[phi' theta'];
phi0c=repmat(phi0,length(phi),1);
phi0c=phi0c';
theta0c=repmat(theta0,length(phi),1);
theta0c=theta0c';
phic=repmat(phi,length(phi0),1);
thetac=repmat(theta,length(phi0),1);
d=acos(sin(theta0c).*sin(thetac)+cos(theta0c).*cos(thetac).*cos(phi0c-phic));
dg=pi;
% d=d.*(d<pi/3);
% dd=((dg-d)./(dg.*d)).^2;
dd=d.^(-3);
dd(isinf(dd))=0;
[Ag,Ac]=sort(dd);
zn=size(Ac);
if zn(1)>20
  zg=zn(1)-20;
  for i=1:zn(2)
      dd(Ac(1:zg,i),i)=0;
  end
end
ww=dd./sum(dd);
ye=ww'*ys;
enve=ye';
end