function [node,face]=particlegen(EI,e12,e26,e67,e79,N)
a12=e12;
a67=e67;
aa=e26;
bb=e79;
A=zeros(1,9);
r=zeros(9,N);
% 
A(1)=EI;
A(2)=a12*A(1);
nn=3:11;
NN=2.^(nn);
BP=[1 0 0;-1 0 0;0 1 0;0 -1 0;0 0 1;0 0 -1];
%
xf=(BP(:,1))';
yf=(BP(:,3))';
zf=(BP(:,3))';
[phim,thetam,rf]=cart2sph(xf,yf,zf);
phi0=phim;
theta0=thetam;
%
rfxx=A(1)*rand(1,3);
rfx1=rfxx.*rand(1,3);
rfx2=rfxx-rfx1;
rf0=[rfx1(1) rfx2(1) rfx1(2) rfx2(2) rfx1(3) rfx2(3)];
% 
fai=(sqrt(5)-1)/2;
for i=1:N
    z(i)=(2*i-1)/N-1;
    x(i)=sqrt(1-z(i)^2)*cos(2*pi*i*fai);
    y(i)=sqrt(1-z(i)^2)*sin(2*pi*i*fai);
end
[phi,theta,rgg]=cart2sph(x,y,z);
xs=[phi0' theta0'];
ys=rf0';
xe=[phi' theta'];
phi0c=repmat(phi0,length(phi),1);
phi0c=phi0c';
theta0c=repmat(theta0,length(phi),1);
theta0c=theta0c';
phic=repmat(phi,length(phi0),1);
thetac=repmat(theta,length(phi0),1);
d=acos(sin(theta0c).*sin(thetac)+cos(theta0c).*cos(thetac).*cos(phi0c-phic));
dg=pi;
dd=d.^(-3);
dd(isinf(dd))=0;
ww=dd./sum(dd);
ye=ww'*ys;
r(1,:)=ye';
%
for i=2:6
    A(i)=A(2)*(2/i)^(aa);
    r(i,:)=imfgenerate(NN(i),A(i));
end
%
A(7)=A(6)*a67;
for i=7:9
    A(i)=A(7)*(7/i)^(bb);
    r(i,:)=imfgenerate(NN(i),A(i));
end
%
rr=sum(r);
R = abs(rr);
phi=phi+pi;
theta=theta+pi/2;
Rxy = R.*sin(theta);   
x = Rxy.*cos(phi);
y = Rxy.*sin(phi);
z = R.*cos(theta);
node=[x',y',z'];
[face]=facegen(node);
%savebinstl(node,t,'xxx');
end

function rg=imfgenerate(N,A)
for i=1:N
   x(i)=normrnd(0,1);
   y(i)=normrnd(0,1);
   z(i)=normrnd(0,1);
   xf(i)=x(i)/sqrt(x(i)^2+y(i)^2+z(i)^2);
   yf(i)=y(i)/sqrt(x(i)^2+y(i)^2+z(i)^2);
   zf(i)=z(i)/sqrt(x(i)^2+y(i)^2+z(i)^2);
end
[phim,thetam,rf]=cart2sph(xf,yf,zf);
phi0=phim;
theta0=thetam;
rf0 = A*rand(1,length(rf));
fai=(sqrt(5)-1)/2;
for i=1:N
    z(i)=(2*i-1)/N-1;
    x(i)=sqrt(1-z(i)^2)*cos(2*pi*i*fai);
    y(i)=sqrt(1-z(i)^2)*sin(2*pi*i*fai);
end
[phi,theta,r]=cart2sph(x,y,z);
xs=[phi0' theta0'];
ys=rf0';
xe=[phi' theta'];
phi0c=repmat(phi0,length(phi),1);
phi0c=phi0c';
theta0c=repmat(theta0,length(phi),1);
theta0c=theta0c';
phic=repmat(phi,length(phi0),1);
thetac=repmat(theta,length(phi0),1);
d=acos(sin(theta0c).*sin(thetac)+cos(theta0c).*cos(thetac).*cos(phi0c-phic));
dg=pi;
dd=d.^(-3);
dd(isinf(dd))=0;
ww=dd./sum(dd);
ye=ww'*ys;
rg=ye';
end


