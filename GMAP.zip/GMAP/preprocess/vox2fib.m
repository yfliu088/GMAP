function [node,face]=vox2fib(img,node_fp,t_fp)
I=img;
%
[rows,cols,mal] = size(I);
x=1:rows;y=1:cols;z=1:mal;
[x,y,z]=meshgrid(x,y,z);
area = sum(sum(sum(I))); 
meanx = sum(sum(sum(I.*x)))/area; 
meany = sum(sum(sum(I.*y)))/area;
meanz = sum(sum(sum(I.*z)))/area;
%
tes=bwperim(I);
[xx,yy,zz] = ind2sub(size(tes),find(tes == 1));
xx=xx-meanx;
yy=yy-meany;
zz=zz-meanz;
[theta0,lambda0,r0]=cart2sph(xx,yy,zz);
theta0=theta0+pi;
lambda0=lambda0+pi/2;
%
phim=node_fp(:,1);
thetam=node_fp(:,2);
%
phi=phim+pi;
theta=pi/2-thetam;
r = griddata(theta0,lambda0,r0,phi,theta,'nearest');
R = abs(r);       
Rxy = R.*sin(theta);    
x = Rxy.*cos(phi);
y = Rxy.*sin(phi);
z = R.*cos(theta);
node=[-x',-y',z'];
face=t_fp;
end

